from pathlib import Path
import ast
import shutil
import re

TARGET = Path("/usr/local/bin/llm")
BACKUP = TARGET.with_name("llm.bak.pre_programming_fastpath")

if not TARGET.is_file():
    raise SystemExit(f"ABORT: target not found: {TARGET}")

if BACKUP.exists():
    raise SystemExit(f"ABORT: backup already exists: {BACKUP}")

source = TARGET.read_text(encoding="utf-8")

if "def model_chat(model, messages):" not in source:
    raise SystemExit("ABORT: model_chat definition not found")

if "def programming_fast_path(text):" in source:
    raise SystemExit("ABORT: programming fast path already exists")

if source.count("def model_chat(model, messages):") != 1:
    raise SystemExit("ABORT: unexpected model_chat definition count")

helper = r'''
def programming_fast_path(text):
    """Deterministic programming dispatcher; never calls a model."""
    if not isinstance(text, str):
        return None

    low = re.sub(r"\s+", " ", text.lower()).strip()

    intent = re.search(
        r"\b(write|create|generate|implement|build|code|program|"
        r"programming|script|function|class|algorithm|unit test|"
        r"test suite|hello world|factorial|fibonacci|fizzbuzz|"
        r"countdown|for loop|while loop|parser|compiler|"
        r"source code|code snippet|debug|refactor)\b",
        low,
    )
    if not intent:
        return None

    if re.search(r"\bc\s*(?:#|sharp)\b", low):
        lang = "csharp"
    elif re.search(r"\bc\+\+|\bcpp\b|c plus plus", low):
        lang = "cpp"
    elif re.search(r"\bpython(?:\s*3)?\b", low):
        lang = "python"
    elif re.search(
        r"\b(?:in c|c language|c program|write c code|"
        r"language\s*=\s*c)\b", low
    ):
        lang = "c"
    else:
        return (
            "PROGRAMMING FAST PATH: Specify Python, C, C++, or C#. "
            "No model was called."
        )

    def unsupported():
        return (
            f"PROGRAMMING FAST PATH: No deterministic {lang} handler "
            "matches this request. No model was called. Add an explicit "
            "handler for this task to enable it."
        )

    def emit(body):
        if lang == "python":
            return body + "\n"

        if lang == "c":
            return (
                "#include <stdio.h>\n"
                "#include <string.h>\n"
                "#include <stdbool.h>\n\n"
                "int main(void) {\n" +
                "".join("    " + x + "\n" for x in body.splitlines()) +
                "    return 0;\n}\n"
            )

        if lang == "cpp":
            return (
                "#include <iostream>\n"
                "#include <string>\n"
                "#include <algorithm>\n"
                "#include <vector>\n"
                "#include <cstdlib>\n\n"
                "int main() {\n" +
                "".join("    " + x + "\n" for x in body.splitlines()) +
                "    return 0;\n}\n"
            )

        return (
            "using System;\n"
            "using System.Linq;\n\n"
            "class Program\n{\n"
            "    static void Main()\n    {\n" +
            "".join("        " + x + "\n"
                    for x in body.splitlines()) +
            "    }\n}\n"
        )

    nmatch = re.search(r"\bn\s*=\s*(\d+)", low)
    n = int(nmatch.group(1)) if nmatch else 5

    fmatch = re.search(r"\bfactorial\s*(?:of\s*)?(\d+)", low)
    if fmatch:
        n = int(fmatch.group(1))

    if "hello" in low and "world" in low:
        if lang == "python":
            return 'print("Hello, world!")\n'
        if lang == "c":
            return '#include <stdio.h>\n\nint main(void) {\n    puts("Hello, world!");\n    return 0;\n}\n'
        if lang == "cpp":
            return '#include <iostream>\n\nint main() {\n    std::cout << "Hello, world!\\n";\n    return 0;\n}\n'
        return 'using System;\n\nclass Program {\n    static void Main() {\n        Console.WriteLine("Hello, world!");\n    }\n}\n'

    if "factorial" in low:
        if not 0 <= n <= 20:
            return "PROGRAMMING FAST PATH: factorial supports n from 0 to 20."
        if lang == "python":
            return (
                "import math\n\n"
                f"n = {n}\n"
                "print(math.factorial(n))\n"
            )
        if lang == "c":
            return emit(
                f"unsigned long long result = 1;\n"
                f"for (int i = 2; i <= {n}; ++i) result *= i;\n"
                "printf(\"%llu\\n\", result);"
            )
        if lang == "cpp":
            return emit(
                f"unsigned long long result = 1;\n"
                f"for (int i = 2; i <= {n}; ++i) result *= i;\n"
                "std::cout << result << '\\n';"
            )
        return emit(
            f"ulong result = 1;\n"
            f"for (int i = 2; i <= {n}; ++i) result *= (ulong)i;\n"
            "Console.WriteLine(result);"
        )

    if "fibonacci" in low:
        if not 0 <= n <= 100:
            return "PROGRAMMING FAST PATH: Fibonacci supports n from 0 to 100."
        if lang == "python":
            return (
                f"n = {n}\na, b = 0, 1\n"
                "for _ in range(n):\n"
                "    print(a)\n"
                "    a, b = b, a + b\n"
            )
        if lang == "c":
            return emit(
                f"unsigned long long a = 0, b = 1;\n"
                f"for (int i = 0; i < {n}; ++i) {{\n"
                '    printf("%llu\\n", a);\n'
                "    unsigned long long t = a + b;\n"
                "    a = b; b = t;\n}"
            )
        if lang == "cpp":
            return emit(
                f"unsigned long long a = 0, b = 1;\n"
                f"for (int i = 0; i < {n}; ++i) {{\n"
                "    std::cout << a << '\\n';\n"
                "    auto t = a + b; a = b; b = t;\n}"
            )
        return emit(
            f"ulong a = 0, b = 1;\n"
            f"for (int i = 0; i < {n}; ++i) {{\n"
            "    Console.WriteLine(a);\n"
            "    ulong t = a + b; a = b; b = t;\n}"
        )

    if "prime" in low:
        if not 2 <= n <= 1000000000:
            return "PROGRAMMING FAST PATH: prime handler supports n from 2 to 1000000000."
        if lang == "python":
            return (
                f"n = {n}\n"
                "is_prime = n >= 2 and all("
                "n % i for i in range(2, int(n ** 0.5) + 1))\n"
                "print(is_prime)\n"
            )
        if lang == "c":
            return emit(
                f"int n = {n};\n"
                "bool prime = true;\n"
                "for (int i = 2; (long long)i * i <= n; ++i)\n"
                "    if (n % i == 0) { prime = false; break; }\n"
                'printf("%s\\n", prime ? "true" : "false");'
            )
        if lang == "cpp":
            return emit(
                f"int n = {n};\n"
                "bool prime = true;\n"
                "for (int i = 2; (long long)i * i <= n; ++i)\n"
                "    if (n % i == 0) { prime = false; break; }\n"
                'std::cout << (prime ? "true" : "false") << "\\n";'
            )
        return emit(
            f"int n = {n};\n"
            "bool prime = true;\n"
            "for (int i = 2; (long long)i * i <= n; ++i)\n"
            "    if (n % i == 0) { prime = false; break; }\n"
            'Console.WriteLine(prime ? "true" : "false");'
        )

    if "fizzbuzz" in low:
        if not 1 <= n <= 100000:
            return "PROGRAMMING FAST PATH: FizzBuzz supports n from 1 to 100000."
        if lang == "python":
            return (
                f"for i in range(1, {n} + 1):\n"
                '    print("Fizz" * (i % 3 == 0) + '
                '"Buzz" * (i % 5 == 0) or i)\n'
            )
        if lang == "c":
            return emit(
                f"for (int i = 1; i <= {n}; ++i) {{\n"
                '    if (i % 15 == 0) puts("FizzBuzz");\n'
                '    else if (i % 3 == 0) puts("Fizz");\n'
                '    else if (i % 5 == 0) puts("Buzz");\n'
                '    else printf("%d\\n", i);\n}'
            )
        if lang == "cpp":
            return emit(
                f"for (int i = 1; i <= {n}; ++i) {{\n"
                '    if (i % 15 == 0) std::cout << "FizzBuzz\\n";\n'
                '    else if (i % 3 == 0) std::cout << "Fizz\\n";\n'
                '    else if (i % 5 == 0) std::cout << "Buzz\\n";\n'
                "    else std::cout << i << '\\n';\n}"
            )
        return emit(
            f"for (int i = 1; i <= {n}; ++i) {{\n"
            '    if (i % 15 == 0) Console.WriteLine("FizzBuzz");\n'
            '    else if (i % 3 == 0) Console.WriteLine("Fizz");\n'
            '    else if (i % 5 == 0) Console.WriteLine("Buzz");\n'
            "    else Console.WriteLine(i);\n}"
        )

    if "countdown" in low or "while loop" in low:
        if not 0 <= n <= 100000:
            return "PROGRAMMING FAST PATH: n must be between 0 and 100000."
        if lang == "python":
            return f"n = {n}\nwhile n > 0:\n    print(n)\n    n -= 1\n"
        if lang == "c":
            return emit(
                f"int n = {n};\nwhile (n > 0) {{\n"
                '    printf("%d\\n", n);\n    --n;\n}'
            )
        if lang == "cpp":
            return emit(
                f"int n = {n};\nwhile (n > 0) {{\n"
                "    std::cout << n << '\\n';\n    --n;\n}"
            )
        return emit(
            f"int n = {n};\nwhile (n > 0) {{\n"
            "    Console.WriteLine(n);\n    --n;\n}"
        )

    if "sum" in low and any(x in low for x in ("range", "0 to", "0..")):
        if not 0 <= n <= 100000:
            return "PROGRAMMING FAST PATH: n must be between 0 and 100000."
        if lang == "python":
            return f"n = {n}\nprint(sum(range(n)))\n"
        if lang == "c":
            return emit(
                f"long long total = 0;\n"
                f"for (int i = 0; i < {n}; ++i) total += i;\n"
                'printf("%lld\\n", total);'
            )
        if lang == "cpp":
            return emit(
                f"long long total = 0;\n"
                f"for (int i = 0; i < {n}; ++i) total += i;\n"
                "std::cout << total << '\\n';"
            )
        return emit(
            f"long total = 0;\n"
            f"for (int i = 0; i < {n}; ++i) total += i;\n"
            "Console.WriteLine(total);"
        )

    if "for loop" in low:
        if not 0 <= n <= 100000:
            return "PROGRAMMING FAST PATH: n must be between 0 and 100000."
        if lang == "python":
            return f"for i in range({n}):\n    print(i)\n"
        if lang == "c":
            return emit(
                f"for (int i = 0; i < {n}; ++i) printf(\"%d\\\\n\", i);"
            )
        if lang == "cpp":
            return emit(
                f"for (int i = 0; i < {n}; ++i) "
                "std::cout << i << '\\\\n';"
            )
        return emit(
            f"for (int i = 0; i < {n}; ++i) Console.WriteLine(i);"
        )

    return unsupported()


'''

marker = "def model_chat(model, messages):\n"
dispatch = (
    marker
    + '    _programming = programming_fast_path(messages[-1]["content"])\n'
    + '    if _programming is not None:\n'
    + '        sys.stdout.write(_programming + "\\n")\n'
    + '        sys.stdout.flush()\n'
    + '        return _programming\n'
)

patched = source.replace(marker, helper + dispatch, 1)

ast.parse(patched, filename=str(TARGET))

# Validate generated Python code for representative supported cases.
ns = {"re": re}
exec(compile(helper, "<programming_fast_path>", "exec"), ns)
for prompt in (
    "Write Python hello world",
    "Write C factorial of 5",
    "Create C++ Fibonacci n=10",
    "Write C# FizzBuzz n=20",
):
    result = ns["programming_fast_path"](prompt)
    if not result:
        raise SystemExit(f"ABORT: test failed: {prompt}")

shutil.copy2(TARGET, BACKUP)
try:
    TARGET.write_text(patched, encoding="utf-8")
    ast.parse(TARGET.read_text(encoding="utf-8"), filename=str(TARGET))
except Exception:
    shutil.copy2(BACKUP, TARGET)
    raise

print("PATCH_OK")
print(f"Backup: {BACKUP}")
print("Syntax validation: OK")
print("Representative handler tests: OK")
