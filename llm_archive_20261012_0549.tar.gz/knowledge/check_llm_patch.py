from pathlib import Path

launcher = Path("/usr/local/bin/llm")
installer = Path("/tmp/patch_python_handlers.py")
backup = Path("/usr/local/bin/llm.bak.before_explicit_python_handlers")

print("LAUNCHER_EXISTS:", launcher.exists())
if launcher.exists():
    s = launcher.read_text()
    print("PATCH_MARKER:", "EXPLICIT_PYTHON_HANDLERS_V1" in s)
    print("WRAPPER_PRESENT:", "_explicit_python_handlers" in s)

print("BACKUP_EXISTS:", backup.exists())
print("INSTALLER_EXISTS:", installer.exists())

if installer.exists():
    lines = installer.read_text().splitlines()
    print("INSTALLER RELEVANT LINES:")
    for i, line in enumerate(lines, 1):
        if any(x in line for x in (
            "PATCH_OK", "marker =", "write_text",
            "unittest.main", "unittest.main()"
        )):
            print(f"{i}: {line}")
