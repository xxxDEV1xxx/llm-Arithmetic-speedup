import importlib.machinery, importlib.util, time

loader = importlib.machinery.SourceFileLoader("llmmod", "/usr/local/bin/llm")
spec = importlib.util.spec_from_loader("llmmod", loader)
mod = importlib.util.module_from_spec(spec)
loader.exec_module(mod)

mod.cpu_mode("active")
mod.freezer("thaw")
t0 = time.time()
idx = mod.kb_load()
print({k: len(v["chunks"]) for k, v in idx.items()})
print("seconds: %.1f" % (time.time() - t0))
mod.cpu_mode("idle")
mod.freezer("freeze")
