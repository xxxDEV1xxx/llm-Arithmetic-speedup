import runpy
import sympy as sp

d = runpy.run_path("/usr/local/bin/llm.new")
x, y = sp.symbols("x y")

tests = [
    "exp of the quantity x squared plus three x",
    "sine of the quantity x cubed plus two x squared plus one",
    "three x cubed plus two x squared minus five x plus seven",
    "x squared plus three x",
]

for text in tests:
    print("\nINPUT:", text)
    try:
        translated = d["_calc_expression"](text)
        print("TRANSLATED:", translated)
    except Exception as e:
        print("TRANSLATION ERROR:", type(e).__name__, str(e))
        continue

    try:
        parsed = d["_calc_sympify"](text, x, y)
        print("PARSED:", parsed)
        print("DERIVATIVE:", sp.diff(parsed, x))
    except Exception as e:
        print("PARSE ERROR:", type(e).__name__, str(e))
