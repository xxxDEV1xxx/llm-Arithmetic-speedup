import importlib.machinery, importlib.util, math

loader = importlib.machinery.SourceFileLoader("llmmod", "/usr/local/bin/llm")
spec = importlib.util.spec_from_loader("llmmod", loader)
mod = importlib.util.module_from_spec(spec)
loader.exec_module(mod)

query = open("/tmp/q2.txt").read().strip()
mod.freezer("thaw")
try:
    idx = mod.kb_load()
    q = mod.kb_embed([query])[0]
    qn = math.sqrt(sum(x * x for x in q)) or 1.0
    rows = []
    for name, e in idx.items():
        for c, v in zip(e["chunks"], e["vecs"]):
            vn = math.sqrt(sum(x * x for x in v)) or 1.0
            rows.append((sum(a * b for a, b in zip(q, v)) / (qn * vn), name, c))
    rows.sort(reverse=True)
    for s, name, c in rows[:6]:
        print("%.3f  %-28s %s" % (s, name, c[:90].replace("\n", " ")))
finally:
    mod.freezer("freeze")
