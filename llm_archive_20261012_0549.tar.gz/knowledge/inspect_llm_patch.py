from pathlib import Path

target = Path("/usr/local/bin/llm")
backup = Path("/usr/local/bin/llm.bak.before_explicit_python_handlers")
source = target.read_text()

print("TARGET_EXISTS:", target.exists())
print("PATCH_MARKER:", "EXPLICIT_PYTHON_HANDLERS_V1" in source)
print("WRAPPER_PRESENT:", "_prior_programming_fast_path" in source)
print("BACKUP_EXISTS:", backup.exists())

print("\nRELEVANT SOURCE LINES:")
for number, line in enumerate(source.splitlines(), 1):
    if any(term in line for term in (
        "programming_fast_path",
        "def model_chat",
        "No deterministic",
        "ollama",
        "urlopen",
        "api/chat",
    )):
        print(f"{number}: {line[:200]}")
