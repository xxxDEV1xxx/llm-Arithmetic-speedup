from pathlib import Path

lines = Path(
    "/tmp/patch_python_handlers.py"
).read_text().splitlines()

for start, end in [(90, 165), (470, 560)]:
    print(f"\n--- LINES {start}-{end} ---")
    for i in range(start - 1, min(end, len(lines))):
        print(f"{i+1}: {lines[i]}")
