import sys
sys.stdout = open("/tmp/perf.out", "w", buffering=1)
import importlib.machinery, importlib.util, json, time, urllib.request

loader = importlib.machinery.SourceFileLoader("llmmod", "/usr/local/bin/llm")
spec = importlib.util.spec_from_loader("llmmod", loader)
mod = importlib.util.module_from_spec(spec)
loader.exec_module(mod)

SYS = ("You are a precise expert assistant running locally on a phone. " * 15)[:900]
Q = "What Reynolds number range is laminar flow in a pipe?"


def meminfo():
    out = {}
    for line in open("/proc/meminfo"):
        k, v = line.split(":", 1)
        if k in ("MemAvailable", "SwapFree"):
            out[k] = int(v.split()[0]) // 1024
    return "MemAvail %(MemAvailable)d MB, SwapFree %(SwapFree)d MB" % out


def call(messages, options):
    payload = {"model": "qwen2.5:1.5b", "messages": messages, "stream": False,
               "think": False, "keep_alive": "30m", "options": options}
    req = urllib.request.Request("http://127.0.0.1:11434/api/chat",
                                 data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json"},
                                 method="POST")
    t0 = time.time()
    with urllib.request.urlopen(req, timeout=900) as r:
        d = json.loads(r.read())
    wall = time.time() - t0
    s = lambda k: d.get(k, 0) / 1e9
    print("   wall %.1fs | load %.1fs | prompt %d tok (%d cached) in %.1fs | gen %d tok in %.1fs"
          % (wall, s("load_duration"), d.get("prompt_eval_count", 0),
             d.get("prompt_eval_cached_count", 0), s("prompt_eval_duration"),
             d.get("eval_count", 0), s("eval_duration")))


A = dict(num_ctx=8192, num_batch=8192, num_thread=3, num_predict=48)
B = dict(A, num_batch=512)
C = dict(A, num_ctx=4096, num_batch=512)

mod.cpu_mode("active")
mod.freezer("thaw")
try:
    msgs = mod.kb_wrap([{"role": "system", "content": SYS}, {"role": "user", "content": Q}])
    print("prompt chars:", sum(len(m["content"]) for m in msgs))
    print("A current (ctx 8192, batch 8192) |", meminfo())
    call(msgs, A)
    call(msgs, A)
    print("A after 60 s frozen")
    mod.freezer("freeze")
    time.sleep(60)
    mod.freezer("thaw")
    print("   ", meminfo())
    call(msgs, A)
    print("B (ctx 8192, batch 512) |", meminfo())
    call(msgs, B)
    call(msgs, B)
    print("C (ctx 4096, batch 512) |", meminfo())
    call(msgs, C)
    call(msgs, C)
    print("end |", meminfo())
    print("DONE")
finally:
    mod.cpu_mode("idle")
    mod.freezer("freeze")
