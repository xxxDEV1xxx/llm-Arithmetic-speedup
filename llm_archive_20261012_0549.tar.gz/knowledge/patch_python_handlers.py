from pathlib import Path
import ast
import re
import shutil

TARGET = Path("/usr/local/bin/llm")
BACKUP = Path("/usr/local/bin/llm.bak.before_explicit_python_handlers")
MARKER = "# EXPLICIT_PYTHON_HANDLERS_V1"

source = TARGET.read_text()

if MARKER in source:
    raise SystemExit("Patch marker already exists; refusing to patch twice.")
if "def programming_fast_path(" not in source:
    raise SystemExit("ERROR: existing programming_fast_path() was not found.")
if "def model_chat(" not in source:
    raise SystemExit("ERROR: model_chat() was not found.")
if BACKUP.exists():
    raise SystemExit(f"Backup already exists: {BACKUP}; inspect it before proceeding.")

wrapper = r'''
# EXPLICIT_PYTHON_HANDLERS_V1
_prior_programming_fast_path = programming_fast_path

def programming_fast_path(text):
    # Explicit deterministic Python handlers; never delegate unmatched Python code tasks.
    s = str(text)
    low = s.lower()

    has_python = bool(re.search(r"\bpython\b", low))
    has_programming_intent = bool(re.search(
        r"\b(write|implement|create|build|generate|code|program|function|"
        r"class|parser|decoder|algorithm|unit tests?|test suite|script)\b",
        low
    ))

    if not (has_python and has_programming_intent):
        return _prior_programming_fast_path(text)

    def result(code):
        return "DETERMINISTIC PYTHON HANDLER\n" + code.strip() + "\n"

    # 10: Complete protocol parser: magic, version, unsigned LEB128 length,
    # payload, and CRC-16/CCITT-FALSE over all preceding packet bytes.
    if ("crc-16" in low or "crc16" in low or
        ("magic header" in low and "variable-length" in low and "checksum" in low)):
        return result(r'''
from dataclasses import dataclass
import unittest

MAGIC = b"PKT1"
VERSION = 1
MAX_PAYLOAD = 65535

@dataclass(frozen=True)
class Packet:
    version: int
    payload: bytes

def crc16(data):
    crc = 0xFFFF
    for byte in data:
        crc ^= byte << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) & 0xFFFF if crc & 0x8000 else (crc << 1) & 0xFFFF
    return crc

def encode_varint(value):
    if value < 0:
        raise ValueError("length must be non-negative")
    out = bytearray()
    while value >= 0x80:
        out.append((value & 0x7F) | 0x80)
        value >>= 7
    out.append(value)
    return bytes(out)

def decode_varint(data, offset=0):
    value = 0
    shift = 0
    start = offset
    while offset < len(data):
        byte = data[offset]
        offset += 1
        value |= (byte & 0x7F) << shift
        if not byte & 0x80:
            if offset - start > 1 and byte == 0:
                raise ValueError("overlong variable-length integer")
            if encode_varint(value) != bytes(data[start:offset]):
                raise ValueError("non-canonical variable-length integer")
            return value, offset
        shift += 7
        if shift >= 35:
            raise ValueError("variable-length integer too large")
    raise ValueError("truncated variable-length integer")

def encode_packet(payload, version=VERSION):
    payload = bytes(payload)
    if len(payload) > MAX_PAYLOAD:
        raise ValueError("payload too large")
    body = MAGIC + bytes([version]) + encode_varint(len(payload)) + payload
    return body + crc16(body).to_bytes(2, "big")

def parse_packet(data):
    data = bytes(data)
    if len(data) < len(MAGIC) + 1 + 1 + 2:
        raise ValueError("truncated packet")
    if data[:len(MAGIC)] != MAGIC:
        raise ValueError("invalid magic header")
    version = data[len(MAGIC)]
    if version != VERSION:
        raise ValueError("unsupported version")
    length, offset = decode_varint(data, len(MAGIC) + 1)
    if length > MAX_PAYLOAD:
        raise ValueError("payload too large")
    end = offset + length
    if len(data) < end + 2:
        raise ValueError("truncated payload or checksum")
    if len(data) != end + 2:
        raise ValueError("length mismatch or trailing data")
    expected = int.from_bytes(data[end:end + 2], "big")
    if crc16(data[:end]) != expected:
        raise ValueError("CRC-16 checksum mismatch")
    return Packet(version=version, payload=data[offset:end])

class ProtocolTests(unittest.TestCase):
    def test_valid(self):
        self.assertEqual(parse_packet(encode_packet(b"hello")).payload, b"hello")
    def test_empty_payload(self):
        self.assertEqual(parse_packet(encode_packet(b"")).payload, b"")
    def test_bad_magic(self):
        packet = bytearray(encode_packet(b"x"))
        packet[0] ^= 1
        with self.assertRaisesRegex(ValueError, "magic"):
            parse_packet(packet)
    def test_unsupported_version(self):
        with self.assertRaisesRegex(ValueError, "version"):
            parse_packet(encode_packet(b"x", version=2))
    def test_truncated(self):
        with self.assertRaises(ValueError):
            parse_packet(encode_packet(b"hello")[:-1])
    def test_bad_crc(self):
        packet = bytearray(encode_packet(b"x"))
        packet[-1] ^= 1
        with self.assertRaisesRegex(ValueError, "CRC"):
            parse_packet(packet)
    def test_truncated_varint(self):
        with self.assertRaisesRegex(ValueError, "variable-length"):
            decode_varint(b"\x80")
    def test_overlong_varint(self):
        with self.assertRaisesRegex(ValueError, "overlong|canonical"):
            decode_varint(b"\x81\x00")
    def test_trailing_bytes(self):
        with self.assertRaisesRegex(ValueError, "trailing|length"):
            parse_packet(encode_packet(b"x") + b"\x00")

if __name__ == "__main__":
    unittest.main()
''')

    # 9: Unsigned LEB128 decoder.
    if "leb128" in low or "variable-length integer" in low:
        return result(r'''
import unittest

def decode_uleb128(data, offset=0, max_bits=64):
    data = bytes(data)
    start = offset
    value = 0
    shift = 0
    max_bytes = (max_bits + 6) // 7
    while offset < len(data):
        byte = data[offset]
        offset += 1
        if offset - start > max_bytes:
            raise ValueError("overlong LEB128 encoding")
        value |= (byte & 0x7F) << shift
        if not byte & 0x80:
            if value >= (1 << max_bits):
                raise ValueError("integer overflow")
            consumed = offset - start
            if encode_uleb128(value) != data[start:offset]:
                raise ValueError("non-canonical LEB128 encoding")
            return value, consumed
        shift += 7
    raise ValueError("truncated LEB128 encoding")

def encode_uleb128(value):
    if value < 0:
        raise ValueError("value must be non-negative")
    out = bytearray()
    while True:
        byte = value & 0x7F
        value >>= 7
        if value:
            out.append(byte | 0x80)
        else:
            out.append(byte)
            return bytes(out)

class LEB128Tests(unittest.TestCase):
    def test_values(self):
        for n in (0, 1, 127, 128, 300, 16384, 2**32):
            encoded = encode_uleb128(n)
            self.assertEqual(decode_uleb128(encoded), (n, len(encoded)))
    def test_truncated(self):
        with self.assertRaisesRegex(ValueError, "truncated"):
            decode_uleb128(b"\x80")
    def test_overlong(self):
        with self.assertRaises(ValueError):
            decode_uleb128(b"\x81\x00")
    def test_offset(self):
        self.assertEqual(decode_uleb128(b"\xff\x02", max_bits=16), (383, 2))

if __name__ == "__main__":
    unittest.main()
''')

    # 8: Type byte + 16-bit big-endian length + payload + additive checksum.
    if "checksum" in low and ("packet" in low or "payload" in low):
        return result(r'''
import unittest

def parse_packet(data, max_payload=65535):
    data = bytes(data)
    if len(data) < 4:
        raise ValueError("truncated packet")
    packet_type = data[0]
    length = int.from_bytes(data[1:3], "big")
    if length > max_payload:
        raise ValueError("payload too large")
    expected_size = 3 + length + 1
    if len(data) < expected_size:
        raise ValueError("truncated payload or checksum")
    if len(data) > expected_size:
        raise ValueError("length mismatch or trailing data")
    payload = data[3:3 + length]
    checksum = data[-1]
    if checksum != sum(payload) % 256:
        raise ValueError("checksum mismatch")
    return {"type": packet_type, "payload": payload}

def encode_packet(packet_type, payload):
    payload = bytes(payload)
    if len(payload) > 65535:
        raise ValueError("payload too large")
    return bytes([packet_type]) + len(payload).to_bytes(2, "big") + payload + bytes([sum(payload) % 256])

class PacketTests(unittest.TestCase):
    def test_valid(self):
        self.assertEqual(parse_packet(encode_packet(3, b"abc")), {"type": 3, "payload": b"abc"})
    def test_bad_checksum(self):
        packet = bytearray(encode_packet(3, b"abc"))
        packet[-1] ^= 1
        with self.assertRaisesRegex(ValueError, "checksum"):
            parse_packet(packet)
    def test_truncated(self):
        with self.assertRaises(ValueError):
            parse_packet(encode_packet(3, b"abc")[:-1])
    def test_trailing(self):
        with self.assertRaisesRegex(ValueError, "trailing|length"):
            parse_packet(encode_packet(3, b"abc") + b"x")

if __name__ == "__main__":
    unittest.main()
''')

    # 7: Two-byte big-endian length followed by payload.
    if "binary" in low and "length" in low and ("packet" in low or "payload" in low):
        return result(r'''
import unittest

def parse_packet(data, max_payload=65535):
    data = bytes(data)
    if len(data) < 2:
        raise ValueError("truncated length header")
    length = int.from_bytes(data[:2], "big")
    if length > max_payload:
        raise ValueError("payload too large")
    if len(data) < 2 + length:
        raise ValueError("truncated payload")
    if len(data) > 2 + length:
        raise ValueError("length mismatch or trailing bytes")
    return data[2:]

class BinaryPacketTests(unittest.TestCase):
    def test_valid(self):
        self.assertEqual(parse_packet(b"\x00\x03abc"), b"abc")
    def test_empty(self):
        self.assertEqual(parse_packet(b"\x00\x00"), b"")
    def test_truncated_header(self):
        with self.assertRaises(ValueError):
            parse_packet(b"\x00")
    def test_truncated_payload(self):
        with self.assertRaisesRegex(ValueError, "truncated"):
            parse_packet(b"\x00\x03ab")
    def test_extra_data(self):
        with self.assertRaisesRegex(ValueError, "length"):
            parse_packet(b"\x00\x01ab")

if __name__ == "__main__":
    unittest.main()
''')

    # 6: Bank account class.
    if "bank account" in low or ("overdraft" in low and "withdraw" in low):
        return result(r'''
import unittest

class BankAccount:
    def __init__(self, balance=0):
        if balance < 0:
            raise ValueError("initial balance cannot be negative")
        self._balance = balance

    @property
    def balance(self):
        return self._balance

    def deposit(self, amount):
        if amount <= 0:
            raise ValueError("deposit must be positive")
        self._balance += amount
        return self._balance

    def withdraw(self, amount):
        if amount <= 0:
            raise ValueError("withdrawal must be positive")
        if amount > self._balance:
            raise ValueError("insufficient funds")
        self._balance -= amount
        return self._balance

class BankAccountTests(unittest.TestCase):
    def test_deposit_withdraw(self):
        account = BankAccount(100)
        self.assertEqual(account.deposit(25), 125)
        self.assertEqual(account.withdraw(40), 85)
    def test_negative_deposit(self):
        with self.assertRaises(ValueError):
            BankAccount().deposit(-1)
    def test_overdraft(self):
        with self.assertRaisesRegex(ValueError, "insufficient"):
            BankAccount(10).withdraw(11)
    def test_zero_withdrawal(self):
        with self.assertRaises(ValueError):
            BankAccount(10).withdraw(0)

if __name__ == "__main__":
    unittest.main()
''')

    # 5: CSV parsing, required headers, malformed rows.
    if "csv" in low and ("column" in low or "row" in low or "dictionary" in low):
        return result(r'''
import csv
import io
import unittest

def parse_csv(text, required_columns):
    reader = csv.DictReader(io.StringIO(text, newline=""))
    headers = reader.fieldnames
    if not headers:
        raise ValueError("missing CSV header")
    missing = set(required_columns) - set(headers)
    if missing:
        raise ValueError("missing required columns: " + ", ".join(sorted(missing)))
    rows = []
    errors = []
    for line_number, row in enumerate(reader, start=2):
        if None in row or any(value is None for value in row.values()):
            errors.append(f"line {line_number}: malformed column count")
            continue
        rows.append(row)
    return rows, errors

class CSVTests(unittest.TestCase):
    def test_valid(self):
        rows, errors = parse_csv("name,age\\nAda,37\\n", ["name", "age"])
        self.assertEqual(rows, [{"name": "Ada", "age": "37"}])
        self.assertEqual(errors, [])
    def test_missing_column(self):
        with self.assertRaisesRegex(ValueError, "missing required"):
            parse_csv("name\\nAda\\n", ["name", "age"])
    def test_malformed_row(self):
        rows, errors = parse_csv("a,b\\n1,2,3\\n4,5\\n", ["a", "b"])
        self.assertEqual(len(rows), 1)
        self.assertEqual(len(errors), 1)

if __name__ == "__main__":
    unittest.main()
''')

    # 4: Recursive merge sort.
    if "merge sort" in low or "mergesort" in low:
        return result(r'''
import unittest

def merge_sort(items):
    items = list(items)
    if len(items) <= 1:
        return items
    middle = len(items) // 2
    left = merge_sort(items[:middle])
    right = merge_sort(items[middle:])
    merged = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            merged.append(left[i]); i += 1
        else:
            merged.append(right[j]); j += 1
    return merged + left[i:] + right[j:]

class MergeSortTests(unittest.TestCase):
    def test_sorted(self):
        self.assertEqual(merge_sort([1, 2, 3]), [1, 2, 3])
    def test_reverse(self):
        self.assertEqual(merge_sort([3, 2, 1]), [1, 2, 3])
    def test_empty(self):
        self.assertEqual(merge_sort([]), [])
    def test_duplicates(self):
        self.assertEqual(merge_sort([2, 1, 2, 1]), [1, 1, 2, 2])

if __name__ == "__main__":
    unittest.main()
''')

    # 3: Case-insensitive word frequencies, ignoring empty strings.
    if "frequency" in low and "word" in low:
        return result(r'''
import unittest

def word_frequencies(words):
    counts = {}
    for item in words:
        word = item.strip().casefold()
        if word:
            counts[word] = counts.get(word, 0) + 1
    return counts

class WordFrequencyTests(unittest.TestCase):
    def test_case_insensitive(self):
        self.assertEqual(word_frequencies(["Cat", "cat", "DOG"]), {"cat": 2, "dog": 1})
    def test_empty_strings(self):
        self.assertEqual(word_frequencies(["", "  ", "fox"]), {"fox": 1})
    def test_empty_input(self):
        self.assertEqual(word_frequencies([]), {})

if __name__ == "__main__":
    unittest.main()
''')

    # 2: Primality.
    if "prime" in low:
        return result(r'''
import unittest

def is_prime(n):
    if not isinstance(n, int) or isinstance(n, bool) or n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False
    divisor = 3
    while divisor * divisor <= n:
        if n % divisor == 0:
            return False
        divisor += 2
    return True

class PrimeTests(unittest.TestCase):
    def test_prime(self):
        self.assertTrue(is_prime(2))
        self.assertTrue(is_prime(17))
    def test_composite(self):
        self.assertFalse(is_prime(9))
    def test_below_two(self):
        self.assertFalse(is_prime(1))
        self.assertFalse(is_prime(0))
        self.assertFalse(is_prime(-7))

if __name__ == "__main__":
    unittest.main()
''')

    # 1: Factorial.
    if "factorial" in low:
        return result(r'''
import math
import unittest

def factorial(n):
    if not isinstance(n, int) or isinstance(n, bool):
        raise TypeError("n must be an integer")
    if n < 0:
        raise ValueError("n must be non-negative")
    return math.factorial(n)

class FactorialTests(unittest.TestCase):
    def test_values(self):
        self.assertEqual(factorial(0), 1)
        self.assertEqual(factorial(1), 1)
        self.assertEqual(factorial(5), 120)
    def test_negative(self):
        with self.assertRaises(ValueError):
            factorial(-1)
    def test_non_integer(self):
        with self.assertRaises(TypeError):
            factorial(2.5)

if __name__ == "__main__":
    unittest.main()
''')

    # Addition.
    if re.search(r"\b(adds?|addition|sum|two integers)\b", low):
        return result(r'''
import unittest

def add_integers(a, b):
    if not isinstance(a, int) or isinstance(a, bool):
        raise TypeError("a must be an integer")
    if not isinstance(b, int) or isinstance(b, bool):
        raise TypeError("b must be an integer")
    return a + b

class AdditionTests(unittest.TestCase):
    def test_positive(self):
        self.assertEqual(add_integers(2, 3), 5)
    def test_negative(self):
        self.assertEqual(add_integers(-2, 3), 1)
    def test_zero(self):
        self.assertEqual(add_integers(0, 0), 0)

if __name__ == "__main__":
    unittest.main()
''')

    return ("PROGRAMMING FAST PATH: No explicit deterministic Python handler "
            "matches this request. No model was called. Add a handler for this task.")

'''

marker = "def model_chat("
idx = source.find(marker)
if idx < 0:
    raise SystemExit("ERROR: cannot locate model_chat() insertion point.")

patched = source[:idx] + wrapper + "\n\n" + source[idx:]
ast.parse(patched)

shutil.copy2(TARGET, BACKUP)
TARGET.write_text(patched)
ast.parse(TARGET.read_text())

print("PATCH_OK")
print(f"Backup: {BACKUP}")
print("Syntax validation: OK")
