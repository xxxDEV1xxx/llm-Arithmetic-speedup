from pathlib import Path
import shutil
import re
import ast

path = Path("/data/local/nhsystem/kali-arm64/usr/local/bin/llm")
source = path.read_text(encoding="utf-8")

backup = path.with_name("llm.bak.pre_deterministic_programming")
if backup.exists():
    raise SystemExit(f"ABORT: backup already exists: {backup}")
shutil.copy2(path, backup)

if "def programming_fast_path(text):" in source:
    raise SystemExit("ABORT: programming_fast_path already exists")
if source.count("def model_chat(model, messages):") != 1:
    raise SystemExit("ABORT: unexpected model_chat definition count")

helper = r'''
def programming_fast_path(text):
    """Deterministic programming dispatcher. Never calls a model."""
    if not isinstance(text, str):
        return None

    low = re.sub(r"\s+", " ", text.lower()).strip()

    intent = bool(re.search(
        r"\b(?:write|create|generate|implement|build|make|code|"
        r"program|programming|source code|code snippet|unit test|"
        r"test suite|parser|compiler|script|algorithm|for loop|"
        r"while loop|hello world|factorial|nested loop|countdown|"
        r"binary protocol|coding lesson|lesson\s*[12]|shape [abc])\b",
        low
    ))
    if not intent:
        return None

    if re.search(r"\b(?:c#|c-sharp|c sharp)\b", low):
        language = "csharp"
    elif re.search(r"\b(?:c\+\+|cpp|c plus plus)\b", low):
        language = "cpp"
    elif re.search(
        r"\b(?:python|python 3)\b", low
    ):
        language = "python"
    elif re.search(
        r"\b(?:c program|write (?:a )?c\b|in c\b|emit c\b|"
        r"language\s*=\s*c\b|c language)\b", low
    ):
        language = "c"
    else:
        return (
            "LOCAL FAST PATH: No language-specific handler selected. "
            "Specify Python, C, C++, or C#. Model fallback is disabled "
            "for programming requests."
        )

    # Reuse the existing, deterministic Python and C generators.
    if language in ("python", "c"):
        result = coding_emit_fast_path(text)
        if result is not None:
            return result

    def cpp_program(lines):
        body = "\n".join("    " + line for line in lines)
        return (
            "#include <iostream>\n"
            "int main() {\n" + body +
            "\n    return 0;\n}\n"
        )

    def csharp_program(lines):
        body = "\n".join("        " + line for line in lines)
        return (
            "using System;\n\n"
            "class Program\n{\n"
            "    static void Main()\n    {\n" + body +
            "\n    }\n}\n"
        )

    if language in ("cpp", "csharp"):
        emit = cpp_program if language == "cpp" else csharp_program

        if "hello" in low and (
            "world" in low or "template" in low or "scaffold" in low
        ):
            line = (
                'std::cout << "Hello, world!" << std::endl;'
                if language == "cpp"
                else 'Console.WriteLine("Hello, world!");'
            )
            return emit([line])

        if "factorial" in low:
            match = re.search(r"\bfactorial\s*(?:of\s*)?(\d+)", low)
            n_match = re.search(r"\bn\s*=\s*(\d+)", low)
            n = int(match.group(1)) if match else (
                int(n_match.group(1)) if n_match else 5
            )
            if not 0 <= n <= 20:
                return (
                    "LOCAL FAST PATH: factorial handler accepts n from "
                    "0 through 20 only."
                )
            if language == "cpp":
                return emit([
                    f"int n = {n};",
                    "unsigned long long result = 1;",
                    "for (int i = 2; i <= n; ++i) result *= i;",
                    "std::cout << result << std::endl;"
                ])
            return emit([
                f"int n = {n};",
                "ulong result = 1;",
                "for (int i = 2; i <= n; ++i) result *= (ulong)i;",
                "Console.WriteLine(result);"
            ])

        n_match = re.search(r"\bn\s*=\s*(\d+)", low)
        n = int(n_match.group(1)) if n_match else 5

        if ("countdown" in low or
                ("while loop" in low and "print" in low)):
            if not 0 <= n <= 100000:
                return "LOCAL FAST PATH: n must be between 0 and 100000."
            if language == "cpp":
                return emit([
                    f"int n = {n};",
                    "while (n > 0) {",
                    "    std::cout << n << std::endl;",
                    "    --n;",
                    "}"
                ])
            return emit([
                f"int n = {n};",
                "while (n > 0)",
                "{",
                "    Console.WriteLine(n);",
                "    --n;",
                "}"
            ])

        if "for loop" in low and (
            "print" in low or "display" in low or "loop" in low
        ):
            if not 0 <= n <= 100000:
                return "LOCAL FAST PATH: n must be between 0 and 100000."
            if language == "cpp":
                return emit([
                    f"for (int i = 0; i < {n}; ++i) {{",
                    "    std::cout << i << std::endl;",
                    "}"
                ])
            return emit([
                f"for (int i = 0; i < {n}; ++i)",
                "{",
                "    Console.WriteLine(i);",
                "}"
            ])

        if "sum" in low and any(
            term in low for term in ("range", "0..", "0 to", "lesson 1")
        ):
            if not 0 <= n <= 100000:
                return "LOCAL FAST PATH: n must be between 0 and 100000."
            if language == "cpp":
                return emit([
                    "long long total = 0;",
                    f"for (int i = 0; i < {n}; ++i) total += i;",
                    "std::cout << total << std::endl;"
                ])
            return emit([
                "long total = 0;",
                f"for (int i = 0; i < {n}; ++i) total += i;",
                "Console.WriteLine(total);"
            ])

    # Fail closed: never let an unimplemented coding request reach the API.
    return (
        f"LOCAL FAST PATH: No deterministic {language} handler matches "
        "this request yet. No model was called and no code was generated. "
        "Use a supported task (hello world, factorial, countdown, "
        "for loop, or sum where implemented), or add a dedicated "
        "deterministic handler for this task."
    )


'''

source = source.replace(
    "def model_chat(model, messages):\n",
    helper + "def model_chat(model, messages):\n",
    1
)

marker = "def model_chat(model, messages):\n"
dispatch = (
    marker
    + '    _programming = programming_fast_path(messages[-1]["content"])\n'
    + '    if _programming is not None:\n'
    + '        sys.stdout.write(_programming + "\\n")\n'
    + '        sys.stdout.flush()\n'
    + '        return _programming\n'
)
source = source.replace(marker, dispatch, 1)

ast.parse(source, filename=str(path))
path.write_text(source, encoding="utf-8")
print("PATCH_OK")
print(f"Backup: {backup}")
print("Python syntax: OK")
