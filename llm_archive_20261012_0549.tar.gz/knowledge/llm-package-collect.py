
import os, tarfile
from pathlib import Path
root = Path("/data/local/tmp/llm-package-stage")
root.mkdir(parents=True, exist_ok=True)
archive = root / "collected.tar"
paths = ['/usr/local/bin/llm', '/usr/local/bin/llm.new', '/usr/local/bin/ollama', '/etc/ollama', '/etc/environment', '/etc/profile', '/etc/profile.d', '/root/.bashrc', '/root/.profile', '/root/.config', '/root/.ollama/models/manifests', '/root/.ollama/models/blobs', '/tmp/check_calc.py']
with tarfile.open(archive, "w") as t:
    for raw in paths:
        p = Path(raw)
        if p.exists():
            t.add(str(p), arcname="files" + raw, recursive=True)
            print("Collected:", raw)
